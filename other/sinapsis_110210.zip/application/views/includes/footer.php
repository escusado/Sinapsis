		</div> <!-- content float left -->
		<div class="break"></div>
	</div> <!-- wrapper -->

	<div id="footer">
		<div id="footer_info">
			footer info
		</div>
	</div>
	
</body>
</html>