<!--load header-->
<?php $this->load->view('includes/header'); ?>

Hello Amin

<?php echo anchor('board/create_user_form','Create new user'); ?>


<!--load footer-->
<?php $this->load->view('includes/footer'); ?>