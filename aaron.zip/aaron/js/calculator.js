$(document).ready(function(){
	
	$('<div class="container"></div>').appendTo('body');
	$('<h1>Choose your operation</h1>').appendTo('.container');
	$('<div id="opCntnr" class="clear"></div>').insertAfter('h1');
	$('<div id="output">&nbsp;</div>').appendTo('#opCntnr');
	$('<input class="oprtn rounded shadow" id="oprtn1" type="button" value="+" />').appendTo('#opCntnr');
	$('<input class="oprtn rounded shadow" id="oprtn2" type="button" value="-" />').insertAfter('#oprtn1');
	$('<input class="oprtn rounded shadow" id="oprtn3" type="button" value="x" />').insertAfter('#oprtn2');
	$('<input class="oprtn rounded shadow" id="oprtn4" type="button" value="/" />').insertAfter('#oprtn3');
	$('<input type="text" id="id_display" name="name_display" />').appendTo('#opCntnr');
	$('<div class="clear"></div>').insertAfter('#id_display');

	
	
	keyboard();

	// on click, will display the selected operation
	$(".oprtn").click(function () {      
    	var text = $(this).val();
      	$("#output").html(text);
    });
	
	//increase the count till 9
	function countToNine (){
	for(var x = 0 ; x<10 ; x+=1);}

	//draw the buttons
	function keyboard (){
		for(var x = 0 ; x<10 ; x+=1){
			$('<input class="numeric" type="button" />').insertAfter('#oprtn4');
			&('.numeric').countToNine();
	}}










});

//muestr un menu
// 1 suma, 2 resta, 3 division, 4 producto, 5 porcentaje

//recibir opcion del usuario

//confimar operación
//su  operación deseada es 2 resta
//$('#confirmacion').html('su  operación deseada es 2 resta');


//recibir parametros
//escriba los valores a restar a-b
//recibir va1 y val2



//recibir valores del uauario
//val1 = $('#input_1').value();	

	



//ejecutar funcion correspondiente a la opción seleccionada

//asignar a variable var resultado

//mostrar resultado
//la resta de val1 - val2 es resultado


/***********************************************************/
	/*var una_suma;
	/*una_suma = sumar(5,6);
	/*console.log(una_suma);
	/* //una_suma = 11;*/

	/*function sumar(pa,pb){
		var pr;
		pr = pa+pb;
		return pr;
	}*/
/****************************************/
	/*muestra_suma(3,4);

	function muestra_suma(pa,pb){
		var pr;
		pr = pa+pb;
		console.log(pr);
	}
/***************************************/
	/*saludame();

	function saludame(){
		console.log('hola');
	}
/**************************************/

	/*var hoy = get_day();

	function get_day(){
		return currentTime.getDate();
	}*/