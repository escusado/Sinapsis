jQuery(document).ready(function(){
	jQuery('#element1').css({	
		'display': 'block',
		'overflow':'hidden'		
	});
	jQuery('<div class="footLongTop"><br><div class="footLongBg"></div>').insertAfter('#element1');


	// select the father for the footer and removes it
	var footerFather = jQuery('#footerContainer').parent();
	jQuery('.footLongBg').append(jQuery('#footerContainer'));
	jQuery(footerFather).remove();
	

	//place the absolute div to the bottom of the page
	var document_height = jQuery('html').height();
	var window_height = jQuery(window).height();
	
	if ( jQuery.browser.msie ) {
		document_height = jQuery('body').height();
	}

	place_footer(document_height, window_height);

	jQuery(window).resize(function(){
		document_height = jQuery('html').height();
		window_height = jQuery(window).height();
		
		if ( jQuery.browser.msie ) {
			document_height = jQuery('body').height();
		}
		place_footer(document_height, window_height);
	});

	
	//calculate the difference between the top of the footer and the end of the window
	function place_footer (document_height, window_height){
		jQuery('.footLongTop').offset({ top: document_height, left: 0 });
		var footer_gap = (window_height - document_height) - 12;

		// necessary fix due minimum height issues
		if (footer_gap < 100){
			footer_gap = 100;
		}

		jQuery('.footLongBg').height(footer_gap);

	}

});