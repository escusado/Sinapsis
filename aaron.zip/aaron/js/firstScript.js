$(function() { // document ready shortcut

//$(document).ready(function(){  //document ready without shortcut
	
	//console.log($('tbody tr:even'));
	//alert($('p:first,h1,strong,a').length + ' elements!'); //cuenta los elementos seleccionados y despliega una alerta
	

	//var fontSize = $('h1').css('font-size'); //lee el font size del h1
	//alert(fontSize);	//despliega en un alert el font size de la seleccion
	
	
	
	/*$('h1').css({	//metodo usado para ingresar varias propiedades css
		'fontSize': '32px',
		'margin':'0', 
		'padding':'0',
		'line-height':'35px'
		
	});*/

	/***** add/remove class*****/
	$('tbody tr:even').css('background-color', '#dd00ff');
	
	$('h1:even').addClass('red whiteBg');
	$('.removeThis').removeClass('removeThis');
	
	/******** hide button **********/
	/*$('.clickMe').click(function() {
		$('#footer').hide();
	});*/
	
	/******** hide/show *********/
	// $('.clickMe').click(function() {
	// 	if ($('#footer').is(':visible')) {
	// 	$('#footer').hide();
	// 	} else {
	// 	$('#footer').show();
	// 	}
	// });

	/***** display only if javascript available ********/
	// $('<div id="toggleButton">toggle footer <b class="on">on</b><b class="off">off</b></div>').insertBefore('#footer');
	
	/************ fades in/out *****/
	// $('#toggleButton').click(function() {
		
	// 	if ($('.on').is(':visible')) {
	// 		$('.on').hide();
	// 		$('.off').show();
	// 		$('#footer').fadeIn(1000);
	// 		} else {
	// 		$('.on').show();
	// 		$('.off').hide();
	// 		$('#footer').fadeOut(1000);
	// 	}
	// });

	/********** toggle on/off with mouseover *********/
	$('#toggleButton').click(function() {
		$('#footer').slideToggle('slow');
		if ($('.on').is(':visible')) {
			$('.on').hide();
			$('.off').show();
			$('#toggleButton').css('background','#ddd');
			} else {
			$('.on').show();
			$('.off').hide();
			$('#toggleButton').css('background','#ccc');
		}
	});


	/*** insert a footer before the body close ****/

	$('<div class="footLong">asdasdasd</div>').insertAfter('.container');

	animation1();
	animation2();
	animation3();
	animation4();
	function animation1(){
		console.log ('1');
		$('h1').animate({
			padding: '0px',
			borderBottom: '3px solid gray',
			borderRight: '3px solid gray',
			backgroundColor: 'green'
		}, 200, 'linear');
		
	}
	function animation2(){
		console.log ('2');
		$('h1').animate({
		padding: '20px',
		borderBottom: '3px solid #8f8f8f',
		borderRight: '3px solid #bfbfbf',
		backgroundColor: '#cdcdff'
		}, 200, 'linear');
	}

	function animation3(){
		console.log ('3');
		$('div').animate({
		backgroundColor: 'beige'
		}, 200, 'linear');
	}

	function animation4(){
		console.log ('4');
		$('div').animate({
		backgroundColor: 'white'
		}, 200, 'linear');
	}
	
});