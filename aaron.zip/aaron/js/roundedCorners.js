jQuery(document).ready(function(){

	jQuery('<div class="lftBrdBl"></div>').appendTo('div.tabsFeature ul li:not(.selected)');
	jQuery('<div class="rgtBrdBl"></div>').prependTo('div.tabsFeature ul li:not(.selected)');
	
	jQuery('<div class="lftBrdOrg"></div>').appendTo('div.tabsFeature ul li.selected');
	jQuery('<div class="rgtBrdOrg"></div>').prependTo('div.tabsFeature ul li.selected');

});